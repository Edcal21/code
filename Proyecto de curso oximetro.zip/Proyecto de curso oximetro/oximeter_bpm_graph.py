from max30102 import MAX30102, MAX30105_PULSE_AMP_MEDIUM # Importar la clase MAX30102 y una constante de amplitud de pulso
from machine import SoftI2C, I2C, Pin # Importar funciones de espera, I2C y Pin
from utime import ticks_diff, ticks_us # Importar funciones relacionadas con el tiempo
from time import sleep  # Importar la función sleep del módulo time
from sh1106 import SH1106_I2C # Importar la clase para la pantalla OLED SH1106

# Configurar el pin 2 como salida para el LED
led = Pin(2, Pin.OUT)

# Tamaño máximo del historial
MAX_HISTORY = 32

# Lista para almacenar el historial de valores
history = []

# Lista para almacenar el historial de latidos
beats_history = []

# Variable para indicar si se detectó un latido
beat = False

# Variable para almacenar el número promedio de latidos
beats = 0

# Variables para almacenar las coordenadas del gráfico en pantalla
last_x = 0
last_y = 0
x = 0

# Definición del corazón (matriz para mostrar un corazón en la pantalla OLED)
HEART = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 0, 0, 0, 1, 1, 0],
    [1, 1, 1, 1, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 0, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0],
]

# Configurar la comunicación I2C con los pines 21 y 22
i2c = SoftI2C(sda=Pin(21), scl=Pin(22), freq=400000)

# Crear una instancia del sensor MAX30102 utilizando la comunicación I2C
sensor = MAX30102(i2c=i2c)

# Escanear el bus I2C para asegurarse de que el sensor esté conectado
if sensor.i2c_address not in i2c.scan():
    print("Sensor no encontrado.")
elif not (sensor.check_part_id()):
    # Verificar que el sensor objetivo sea compatible
    print("ID del dispositivo I2C no corresponde a MAX30102 o MAX30105.")
else:
    print("Sensor conectado y reconocido.")

# Configurar el sensor con la configuración predeterminada
print("Configurando el sensor con la configuración predeterminada.", '\n')
sensor.setup_sensor()

# Establecer la tasa de muestreo en 400
sensor.set_sample_rate(400)

# Establecer el número de muestras promediadas en 8
sensor.set_fifo_average(8)

# Establecer la amplitud de los LED en un valor medio
sensor.set_active_leds_amplitude(MAX30105_PULSE_AMP_MEDIUM)

# Configurar el modo de LED
sensor.set_led_mode(2)

# Pausa de 1 segundo
sleep(1)

# Inicializar la pantalla OLED
oled_width = 128
oled_height = 64
oled_i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=400000)
oled = SH1106_I2C(oled_width, oled_height, oled_i2c)

# Mostrar título en la pantalla OLED
oled.text("OXIMETRO", 0, 0)
oled.show()
sleep(2)
# Limpiar la pantalla OLED
oled.fill(0)

# Tiempo de inicio de la adquisición
t_start = ticks_us()

# Función para calcular el SpO2
def calculate_spo2(ir_reading, red_reading):
    # Implementación del algoritmo Relación de Abosorción de Luz para el cálculo de SpO2

    r = float(ir_reading) / float(red_reading)  # Cálculo de la relación R

    if r > 0.0:
        spo2 = (-45.060 * (r * r)) + (30.354 * r) + 94.845
    else:
        spo2 = 0.0

    return spo2

# Función para mostrar el corazón en la pantalla OLED
def show_heart():
    for y, row in enumerate(HEART):
        for x, c in enumerate(row):
            oled.pixel(x, y, c)

# Bucle principal del programa
while True:
    # Verificar si hay nuevas lecturas en la cola FIFO del sensor
    sensor.check()

    # Comprobar si hay muestras disponibles en el almacenamiento
    if sensor.available():
        # Obtener las lecturas de la cola de almacenamiento
        red_reading = sensor.pop_red_from_storage()
        ir_reading = sensor.pop_ir_from_storage()

        value = red_reading

        # Agregar el valor actual al historial
        history.append(value)

        # Obtener los últimos valores del historial con una longitud máxima de MAX_HISTORY
        history = history[-MAX_HISTORY:]

        # Inicializar variables para el cálculo de umbrales
        minima = 0
        maxima = 0
        threshold_on = 0
        threshold_off = 0

        # Calcular los valores mínimo y máximo en el historial
        minima, maxima = min(history), max(history)

        # Calcular los umbrales para detectar latidos
        threshold_on = (minima + maxima * 3) // 4  # 3/4
        threshold_off = (minima + maxima) // 2  # 1/2

        # Verificar si se detecta un pulso
        if value > 1000:
            if not beat and value > threshold_on:
                beat = True
                led.on()
                # Calcular el tiempo transcurrido y la frecuencia cardíaca en BPM
                t_us = ticks_diff(ticks_us(), t_start)
                t_s = t_us / 1000000
                f = 1 / t_s
                bpm = f * 60

                if bpm < 500:
                    t_start = ticks_us()
                    beats_history.append(bpm)
                    # Obtener los últimos valores de frecuencia cardíaca con una longitud máxima de MAX_HISTORY
                    beats_history = beats_history[-MAX_HISTORY:]
                    # Calcular el promedio de los latidos
                    beats = round(sum(beats_history) / len(beats_history), 2)
                    print("♥ BPM:", beats)
                    # Calcular el SpO2
                    spo2 = calculate_spo2(ir_reading, red_reading)
                    print("SpO2:", spo2)
                    
                    # Borrar el área de texto superior.
                    display.fill_rect(0, 0, 128, 32, 0)

                    # Mostrar el corazón en la pantalla OLED
                    show_heart()
                    #Mostrar los datos de BPM y SpO2 en la pantalla OLED
                    oled.text("BPM: {}".format(beats), 20, 0)
                    oled.text("SpO2: {} %".format(spo2), 0, 20)
                    
                    # Graficar los BPM en la pantalla OLED
                    if x>127:
                        oled.fill(0)  #Limpiar la pantalla OLED
                        last_x = 0
                        x = 0
                        
                    y = 64 - int(32 * (value-minima) / (maxima-minima))
                    oled.line(last_x, last_y, x, y, 1)
                    last_y = y
                    last_x = x  
                    
                    oled.show()
                    x = x + 1

            if beat and value < threshold_off:
                beat = False
                led.off()

        else:
            led.off()
            print('No hay dedo')
            # Limpiar la pantalla OLED
            oled.fill(0)
            # Mostrar un mensaje de "No hay dedo" en la pantalla OLED
            oled.text("No hay dedo", 0, 0)
            oled.show()

