% Modelaci�n de la planta y 
% sintonizaci�n del controlador PID para la humedad de suelo

clc;
clear;

% Cargar las muestras del archivos de Excel
t=xlsread('Muestras para PID Tuner.xlsx', 'A2:A27'); % Tiempo
y=xlsread('Muestras para PID Tuner.xlsx', 'C2:C27'); % Humedad de suelo

datos=iddata(y,t,0.5)
pidTuner % Comando para abrir la herramienta pidTuner