# Project 3

Web Programming with Python and JavaScript
#   c s 5 0 w - p r o j e c t 3 
 
 #   c s 5 0 w - p r o j e c t 3 
 
 En el Proyecto 3, he desarrollado un sitio web llamado pizza utilizando HTML, CSS, Python-django  Esta aplicación permite a los usuarios  pedir pizza, tener su propio carrito de compras, tambien esta para la parte administritiva permite ver el control de los pedidos.
<hr>
Como token persona añadi la funcionalidad manejar los tiempos de los pedidos desde que se ordena hasta que se entregue al restarunte tambien se le muestra ala usuario o cliente el proceso de su pedido.
<hr>

La aplicación utiliza una combinación de tecnologías para su funcionamiento. HTML se utiliza para estructurar y presentar la interfaz de usuario, CSS se utiliza para estilizar la apariencia de la página, y Bootstrap se utiliza como un marco de diseño para facilitar el diseño y la responsividad. Python se utiliza en el lado del servidor para manejar la lógica de negocio

